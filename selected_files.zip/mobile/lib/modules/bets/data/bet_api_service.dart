class BetApiService {
  const BetApiService();
}
