class Bet {
  const Bet();
}
