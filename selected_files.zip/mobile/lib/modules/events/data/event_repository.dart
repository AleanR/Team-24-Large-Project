class EventRepository {
  const EventRepository();
}
