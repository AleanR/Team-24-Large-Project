class EventDetailController {
  const EventDetailController();
}
