class EventsController {
  const EventsController();
}
